#include "G4UserRunAction.hh"
#include "G4Run.hh"
#include "G4RunManager.hh"

#include "G4Accumulable.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include "globals.hh"
#include <fstream>



class G4Run;

class RunAction : public G4UserRunAction
{
  public:
    RunAction();
   ~RunAction() override = default;

    void BeginOfRunAction(const G4Run*) override;
    void EndOfRunAction(const G4Run*) override;

    void AddEdep(G4double edep);
    void AddNoP(G4int nop);
    void AddNoE(G4int noe);

    void WriteToFile(const G4Run* run) {

        G4double edep = fEdep.GetValue();
        G4double nop = fNoP.GetValue();
        G4double noe = fNoE.GetValue();

        std::ofstream PosC(fPosC, std::ios::app);
        std::ofstream ElC(fElC, std::ios::app);
        std::ofstream Results(fResults, std::ios::app);

        PosC << ", " << nop;
        ElC << ", " << noe;

        Results
            << "--------------------End of Global Run-----------------------" << G4endl
            << " Run ID: " << run->GetRunID() << G4endl
            << " Total Events: " << run->GetNumberOfEvent() << G4endl
            //<< " Particles: " << G4endl
            //<< " Energy: " << G4endl
            //<< " Target thickness: " << << G4endl
            << " Energy deposited per run in tungsten target: " << G4BestUnit(edep, "Energy") << G4endl
            << " Number of e+ born during run: " << nop << G4endl
            << " Number of e- born during run: " << noe << G4endl
            << "------------------------------------------------------------" << G4endl << G4endl;
    }

  private:
    G4Accumulable<G4double> fEdep = 0.;
    G4Accumulable<G4int> fNoP = 0;
    G4Accumulable<G4int> fNoE = 0;
    std::string fPosC;
    std::string fElC;
    std::string fResults;
    G4double fThickness;
    };

