#include "G4VUserDetectorConstruction.hh"
#include "G4VSensitiveDetector.hh"
#include "G4Threading.hh"
#include "globals.hh"

#include <CLHEP/Units/SystemOfUnits.h>

class G4VPhysicalVolume;
class G4LogicalVolume;

/// Detector construction class to define materials and geometry.

class DetectorConstruction : public G4VUserDetectorConstruction
{
  public:
    DetectorConstruction();
    ~DetectorConstruction() override;

    G4VPhysicalVolume* Construct() override;

    G4LogicalVolume* GetScoringVolume() const { return fScoringVolume; }
    G4LogicalVolume* GetScoringVolume2() const { return fScoringVolume2; }

  protected:
    G4LogicalVolume* fScoringVolume = nullptr;
    G4LogicalVolume* fScoringVolume2 = nullptr;
};
