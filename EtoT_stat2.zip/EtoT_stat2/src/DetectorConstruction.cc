#include "DetectorConstruction.hh"

#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"
#include "G4RunManager.hh"

#include "G4TransportationManager.hh"
#include "G4ClassicalRK4.hh"

DetectorConstruction::DetectorConstruction(){}

DetectorConstruction::~DetectorConstruction(){}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();
  G4Material* Air  = nist->FindOrBuildMaterial("G4_AIR");

  G4double V_AtomicNumber = 1.;
  G4double V_MassOfMole = 1.008*g/mole;
  G4double V_d = 1.e-25*g/cm3;
  G4double V_t = 2.73*kelvin;
  G4double V_p = 3.e-18*pascal;
  G4Material* Vacuum =
      new G4Material("Vacuum", V_AtomicNumber, V_MassOfMole, V_d, kStateGas, V_t, V_p);

  // Cylinder section shape
  G4double tt_innerRadius = 0.*cm;
  G4double tt_outerRadius = 3*cm;
  G4double tt_hz = 14./2*mm;
  G4double d_hz = 0.005*cm;
  G4double tt_startAngle = 0.*deg;
  G4double tt_spanningAngle = 360.*deg;

  // World
  G4double W_hz = 2 * cm;
  G4double W_outerRadius = 4 * cm;
  G4Material* world_mat = Vacuum;

  // Option to switch on/off checking of volumes overlaps
  G4bool checkOverlaps = true;

  auto solidWorld = new G4Tubs("solidWorld",
                            0,
                            W_outerRadius,
                            W_hz,
                            tt_startAngle,
                            tt_spanningAngle);

  auto logicWorld = new G4LogicalVolume(solidWorld,  // its solid
                                        world_mat,  // its material
                                        "logicWorld");  // its name

  auto physWorld = new G4PVPlacement(nullptr,  // no rotation
                                     G4ThreeVector(),  // at (0,0,0)
                                     logicWorld,  // its logical volume
                                     "World",  // its name
                                     nullptr,  // its mother  volume
                                     false,  // no boolean operation
                                     0,  // copy number
                                     checkOverlaps);  // overlaps checking


  // Tungsten target (tt)
  G4Material* tt_mat = nist->FindOrBuildMaterial("G4_W");
  G4ThreeVector tt_pos = G4ThreeVector(0, 0, 0 * cm);

  auto solidtt = new G4Tubs("Tungsten",
                   tt_innerRadius,
                   tt_outerRadius,
                   tt_hz,
                   tt_startAngle,
                   tt_spanningAngle);

  auto logictt = new G4LogicalVolume(solidtt,  // its solid
                                         tt_mat,  // its material
                                         "Tungsten");  // its name

  new G4PVPlacement(nullptr,  // no rotation
                    tt_pos,  // at position
                    logictt,  // its logical volume
                    "Tungsten",  // its name
                    logicWorld,  // its mother  volume
                    false,  // no boolean operation
                    0,  // copy number
                    checkOverlaps);  // overlaps checking

  // Detector surface (det)
  G4Material* det_mat = Vacuum;
  G4ThreeVector det_pos = tt_pos + G4ThreeVector(0, 0, tt_hz + d_hz);

  auto soliddet = new G4Tubs("Detector",  // its name
                    tt_innerRadius,
                    3. *cm,
                    d_hz,
                    tt_startAngle,
                    tt_spanningAngle);


  auto logicdet = new G4LogicalVolume(soliddet,  // its solid
                                         det_mat,  // its material
                                         "Detector");  // its name

  new G4PVPlacement(nullptr,  // no rotation
                    det_pos,  // at position
                    logicdet,  // its logical volume
                    "Detector",  // its name
                    logicWorld,  // its mother  volume
                    false,  // no boolean operation
                    0,  // copy number
                    checkOverlaps);  // overlaps checking

  // Set Target as scoring volume #1 and Detector as scoring volume #2
  fScoringVolume = logictt;
  fScoringVolume2 = logicdet;

  // always return the physical World
  return physWorld;
}
