#include "RunAction.hh"

#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"

#include "G4AccumulableManager.hh"
#include "G4LogicalVolume.hh"
#include "G4ParticleDefinition.hh"
#include "G4ParticleGun.hh"
#include "G4Run.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"

RunAction::RunAction()
{
  // Register accumulable to the accumulable manager
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Register(fEdep);
  accumulableManager->Register(fNoP);
  accumulableManager->Register(fNoE);
  // Files for output results
  fResults = "R_Common info.txt";
  fPosC = "R_PC.txt";
  fElC = "R_EC.txt";
}

void RunAction::BeginOfRunAction(const G4Run*)
{
  // inform the runManager to save random number seed
  G4RunManager::GetRunManager()->SetRandomNumberStore(false);

  // reset accumulables to their initial values
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Reset();
}

void RunAction::EndOfRunAction(const G4Run* run)
{
  G4int nofEvents = run->GetNumberOfEvent();
  if (nofEvents == 0) return;

  // Merge accumulables
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Merge();

  G4double nop = fNoP.GetValue();

  // Write to file
  if (IsMaster()) {
      WriteToFile(run);
      G4cout << G4endl << "Number of positron: " << nop << G4endl << G4endl;
  }
}

void RunAction::AddEdep(G4double edep)
{
  fEdep += edep;
}

void RunAction::AddNoP(G4int nop)
{
    fNoP += nop;
}

void RunAction::AddNoE(G4int noe)
{
    fNoE += noe;
}
