#include "SteppingAction.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"
#include "RunAction.hh"

#include "G4Event.hh"
#include "G4LogicalVolume.hh"
#include "G4RunManager.hh"
#include "G4Step.hh"

SteppingAction::SteppingAction(EventAction* eventAction) : fEventAction(eventAction) {}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
  if (!fScoringVolume & !fScoringVolume2) {
    const auto detConstruction = static_cast<const DetectorConstruction*>(
      G4RunManager::GetRunManager()->GetUserDetectorConstruction());
    fScoringVolume = detConstruction->GetScoringVolume();
    fScoringVolume2 = detConstruction->GetScoringVolume2();
  }

  // get volume of the current step
  G4LogicalVolume* prevolume =
    step->GetPreStepPoint()->GetTouchableHandle()->GetVolume()->GetLogicalVolume();

  // check if we are in scoring volume
  if (prevolume == fScoringVolume)
  {
      // collect energy deposited in this step
      G4double edepStep = step->GetTotalEnergyDeposit();
      fEventAction->AddEdep(edepStep);
  }

  // check the positron right before it quit the detector
  if (prevolume != fScoringVolume2) return;

  // get poststeppoint volume of the current step
  G4LogicalVolume* postvolume =
    step->GetPostStepPoint()->GetTouchableHandle()->GetVolume()->GetLogicalVolume();

  // check the particle quit the detector front
  if (postvolume == fScoringVolume2) return;

  // Get particle name
  G4String particle = step->GetTrack()->GetParticleDefinition()->GetParticleName();

  /*auto runAction = const_cast<RunAction*>(
      static_cast<const RunAction*>(G4RunManager::GetRunManager()->GetUserRunAction())
      );*/

  if (particle == "e+")
  {
      fEventAction->AddNoP(1);
  }

  // check the electron right before it quiet the target
  if (particle == "e-")
  {
      fEventAction->AddNoE(1);
  }
}

