#include "PrimaryGeneratorAction.hh"

#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
  G4int n_particle = 1;
  fParticleGun = new G4ParticleGun(n_particle);

  // default particle kinematic
  G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
  G4String particleName;
  G4ParticleDefinition* particle = particleTable->FindParticle(particleName = "e-");
  fParticleGun->SetParticleDefinition(particle);
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0., 0., 1.));
  fParticleGun->SetParticleEnergy(20 * MeV);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
  // this function is called at the begining of each event

  /*
  G4double size = 1. * cm;
  G4double x0 = size * (G4UniformRand() - 0.5);
  G4double y0 = size * (G4UniformRand() - 0.5);
  G4double z0 = - 105 * cm;
  */

  // --- Gaussian transverse distribution (1 cm diameter) ---
  G4double sigma = 1.67 * mm;  // σ = 1.67 mm for 1 cm diameter 3 sigma
  G4double x0 = G4RandGauss::shoot(0., sigma);
  G4double y0 = G4RandGauss::shoot(0., sigma);
  G4double z0 = - 1000.26 * cm;

  fParticleGun->SetParticlePosition(G4ThreeVector(x0, y0, z0));

  fParticleGun->GeneratePrimaryVertex(event);
}

