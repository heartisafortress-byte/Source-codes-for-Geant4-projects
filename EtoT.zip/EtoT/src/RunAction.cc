#include "RunAction.hh"

#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"

#include "G4AccumulableManager.hh"
#include "G4LogicalVolume.hh"
#include "G4ParticleDefinition.hh"
#include "G4ParticleGun.hh"
#include "G4Run.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"

RunAction::RunAction()
{
  // Register accumulable to the accumulable manager
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Register(fEdep);
  accumulableManager->Register(fNoP_at);
  accumulableManager->Register(fNoE_at);
  accumulableManager->Register(fNoP_end);
  accumulableManager->Register(fNoE_end);
  accumulableManager->Register(fNoP_ad);
  accumulableManager->Register(fNoE_ad);
  accumulableManager->Register(fNoP_El);
  accumulableManager->Register(fNoE_El);
  accumulableManager->Register(fNoP_gas);
  // Files for output results
  fResults = "R_Common info.txt";
}

void RunAction::BeginOfRunAction(const G4Run*)
{
  // inform the runManager to save random number seed
  G4RunManager::GetRunManager()->SetRandomNumberStore(false);

  // reset accumulables to their initial values
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Reset();
}

void RunAction::EndOfRunAction(const G4Run* run)
{
  G4int nofEvents = run->GetNumberOfEvent();
  if (nofEvents == 0) return;

  // Merge accumulables
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Merge();

  // Getting values after merge
  G4double noe_at = fNoE_at.GetValue();
  G4double nop_at = fNoP_at.GetValue();
  G4double noe_end = fNoE_end.GetValue();
  G4double nop_end = fNoP_end.GetValue();
  G4double noe_ad = fNoE_ad.GetValue();
  G4double nop_ad = fNoP_ad.GetValue();
  G4double noe_El = fNoE_El.GetValue();
  G4double nop_El = fNoP_El.GetValue();
  G4double nop_gas = fNoP_gas.GetValue();

  // Write to file
  if (IsMaster()) {
      G4cout << G4endl << "Positrons born: " << nop_at;
      G4cout << G4endl << "Electrons born: " << noe_at;
      G4cout << G4endl << "Positrons escaped the trap: " << nop_end;
      G4cout << G4endl << "Electrons escaped the trap: " << noe_end;
      G4cout << G4endl << "Positrons adiabatic: " << nop_ad;
      G4cout << G4endl << "Electrons adiabatic: " << noe_ad;
      G4cout << G4endl << "Positrons Electric: " << nop_El;
      G4cout << G4endl << "Electrons Electric: " << noe_El << G4endl;
      G4cout << G4endl << "Positrons in gas: " << nop_gas << G4endl;
      WriteToFile(run);
  }
}

void RunAction::AddEdep(G4double edep)
{
  fEdep += edep;
}

void RunAction::AddNoP_at(G4int nop_at)
{
    fNoP_at += nop_at;
}

void RunAction::AddNoE_at(G4int noe_at)
{
    fNoE_at += noe_at;
}

void RunAction::AddNoP_end(G4int nop_end)
{
    fNoP_end += nop_end;
}

void RunAction::AddNoE_end(G4int noe_end)
{
    fNoE_end += noe_end;
}
void RunAction::AddNoP_ad(G4int nop_ad)
{
    fNoP_ad += nop_ad;
}

void RunAction::AddNoE_ad(G4int noe_ad)
{
    fNoE_ad += noe_ad;
}

void RunAction::AddNoP_El(G4int nop_El)
{
    fNoP_El += nop_El;
}

void RunAction::AddNoE_El(G4int noe_El)
{
    fNoE_El += noe_El;
}

void RunAction::AddNoP_gas(G4int nop_gas)
{
    fNoP_gas += nop_gas;
}
