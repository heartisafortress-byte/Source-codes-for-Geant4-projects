#include "SteppingAction.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"
#include "RunAction.hh"

#include "G4Event.hh"
#include "G4LogicalVolume.hh"
#include "G4RunManager.hh"
#include "G4Step.hh"
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <thread>
#include <mutex>
#include <vector>

std::unordered_set<G4int> ElectronTrackIDs_at;
std::unordered_set<G4int> PositronTrackIDs_at;
std::unordered_set<G4int> ElectronTrackIDs_end;
std::unordered_set<G4int> PositronTrackIDs_end;
std::unordered_set<G4int> ElectronTrackIDs_ad;
std::unordered_set<G4int> PositronTrackIDs_ad;
std::unordered_set<G4int> ElectronTrackIDs_El;
std::unordered_set<G4int> PositronTrackIDs_El;
std::unordered_set<G4int> PositronTrackIDs_gas;

G4int Count = 0;
G4int trackID;
G4int eventID;
G4int uniqueID;
G4double KEner;
G4double stoppingThreshold = 1 * eV;
G4String particleName;
G4ThreeVector PPos;
G4ThreeVector PMom;
std::mutex setMutex;

void addPositronID_at(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    PositronTrackIDs_at.insert(id);
}

void addElectronID_at(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    ElectronTrackIDs_at.insert(id);
}

void addPositronID_end(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    PositronTrackIDs_end.insert(id);
}

void addElectronID_end(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    ElectronTrackIDs_end.insert(id);
}

void addPositronID_ad(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    PositronTrackIDs_ad.insert(id);
}

void addElectronID_ad(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    ElectronTrackIDs_ad.insert(id);
}

void addPositronID_El(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    PositronTrackIDs_El.insert(id);
}

void addElectronID_El(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    ElectronTrackIDs_El.insert(id);
}

void addPositronID_gas(int id) {
    std::lock_guard<std::mutex> lock(setMutex); // Automatically locks/unlocks
    PositronTrackIDs_gas.insert(id);
}

void TrackInfo(const G4Step* step) {
    // Particle ID and name
    trackID = step->GetTrack()->GetTrackID();
    particleName = step->GetTrack()->GetParticleDefinition()->GetParticleName();
    eventID = G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID();
    // Get particle position and momentum
    PPos = step->GetTrack()->GetPosition();
    PMom = step->GetTrack()->GetDynamicParticle()->GetMomentum();
    KEner = step->GetTrack()->GetKineticEnergy();
}

SteppingAction::SteppingAction(EventAction* eventAction) : fEventAction(eventAction) {}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
  std::vector<std::thread> threads;

  // To prevent the endless flying of positrons in the trap
  /*G4double currentTime = step->GetTrack()->GetGlobalTime();
  if(currentTime >= 40.*ns) {
      step->GetTrack()->SetTrackStatus(fStopAndKill);
  }*/

  if (!fScoringVolume_gas & !fScoringVolumeT & !fScoringVolume_at & !fScoringVolume_end & !fScoringVolume_ad & !fScoringVolume_El) {
    const auto detConstruction = static_cast<const DetectorConstruction*>(
      G4RunManager::GetRunManager()->GetUserDetectorConstruction());
    fScoringVolumeT = detConstruction->GetScoringVolumeT();
    fScoringVolume_at = detConstruction->GetScoringVolume_at();
    fScoringVolume_end = detConstruction->GetScoringVolume_end();
    fScoringVolume_ad = detConstruction->GetScoringVolume_ad();
    fScoringVolume_El = detConstruction->GetScoringVolume_El();
    fScoringVolume_gas = detConstruction->GetScoringVolume_gas();
  }

  // get volume of the current step
  G4LogicalVolume* prevolume =
    step->GetPreStepPoint()->GetTouchableHandle()->GetVolume()->GetLogicalVolume();

  // check if we are in Target
  if (prevolume == fScoringVolumeT)
  {
      // collect energy deposited in this step
      G4double edepStep = step->GetTotalEnergyDeposit();
      fEventAction->AddEdep(edepStep);
  }

  TrackInfo(step);
  uniqueID = eventID*100000 + trackID;

  if (particleName == "gamma") return;
  // check the positron in the detector
  if (prevolume == fScoringVolume_at)
  {
      // Files for coordinates and momentum
      std::ofstream X_at("R_X_at.txt", std::ios::app);
      std::ofstream Y_at("R_Y_at.txt", std::ios::app);
      std::ofstream Px_at("R_Px_at.txt", std::ios::app);
      std::ofstream Py_at("R_Py_at.txt", std::ios::app);
      std::ofstream Pz_at("R_Pz_at.txt", std::ios::app);

      if (particleName == "e+")
      {
          Count = PositronTrackIDs_at.size();
          addPositronID_at(uniqueID);
          //G4cout << G4endl << "Particl name: " << particleName << ", uniqueID: " << uniqueID <<  G4endl;

          if (Count < PositronTrackIDs_at.size())
          {
              fEventAction->AddNoP_at(1);
              // Write coordinates and momentum in files
              X_at << PPos[0] << ", ";
              Y_at << PPos[1] << ", ";
              Px_at << PMom[0] << ", ";
              Py_at << PMom[1] << ", ";
              Pz_at << PMom[2] << ", ";
              /*G4cout << G4endl << "Size of the positron unsorted set " << PositronTrackIDs_at.size();
              G4cout << G4endl << "All unique IDs:" << std::endl;
              for (const auto& id : PositronTrackIDs_at) {
                  G4cout << id << G4endl;
              }*/
          }
      } else if (particleName == "e-") {
          Count = ElectronTrackIDs_at.size();
          addElectronID_at(uniqueID);

          if (Count < ElectronTrackIDs_at.size())
          {
              fEventAction->AddNoE_at(1);
          }
      } else return;
  } else if (prevolume == fScoringVolume_ad) {
      // Files for coordinates and momentum
      std::ofstream X_ad("R_X_ad.txt", std::ios::app);
      std::ofstream Y_ad("R_Y_ad.txt", std::ios::app);
      std::ofstream Px_ad("R_Px_ad.txt", std::ios::app);
      std::ofstream Py_ad("R_Py_ad.txt", std::ios::app);
      std::ofstream Pz_ad("R_Pz_ad.txt", std::ios::app);

      if (particleName == "e+")
      {
          Count = PositronTrackIDs_ad.size();
          addPositronID_ad(uniqueID);

          if (Count < PositronTrackIDs_ad.size())
          {
              fEventAction->AddNoP_ad(1);
              // Write coordinates and momentum in files
              X_ad << PPos[0] << ", ";
              Y_ad << PPos[1] << ", ";
              Px_ad << PMom[0] << ", ";
              Py_ad << PMom[1] << ", ";
              Pz_ad << PMom[2] << ", ";
          }
      } else if (particleName == "e-") {
          Count = ElectronTrackIDs_ad.size();
          addElectronID_ad(uniqueID);

          if (Count < ElectronTrackIDs_ad.size())
          {
              fEventAction->AddNoE_ad(1);
          }
      } else return;
  } else if (prevolume == fScoringVolume_El) {
      // Files for coordinates and momentum
      std::ofstream X_El("R_X_El.txt", std::ios::app);
      std::ofstream Y_El("R_Y_El.txt", std::ios::app);
      std::ofstream Px_El("R_Px_El.txt", std::ios::app);
      std::ofstream Py_El("R_Py_El.txt", std::ios::app);
      std::ofstream Pz_El("R_Pz_El.txt", std::ios::app);

      if (particleName == "e+")
      {
          Count = PositronTrackIDs_El.size();
          addPositronID_El(uniqueID);

          if (Count < PositronTrackIDs_El.size())
          {
              fEventAction->AddNoP_El(1);
              // Write coordinates and momentum in files
              X_El << PPos[0] << ", ";
              Y_El << PPos[1] << ", ";
              Px_El << PMom[0] << ", ";
              Py_El << PMom[1] << ", ";
              Pz_El << PMom[2] << ", ";
          }
      } else if (particleName == "e-") {
          Count = ElectronTrackIDs_El.size();
          addElectronID_El(uniqueID);

          if (Count < ElectronTrackIDs_El.size())
          {
              fEventAction->AddNoE_El(1);
          }
      } else return;
  } else if (prevolume == fScoringVolume_gas) {
      if (particleName == "e+")
      {
          std::ofstream X_gas("R_X_gas.txt", std::ios::app);
          std::ofstream Y_gas("R_Y_gas.txt", std::ios::app);
          std::ofstream Z_gas("R_Z_gas.txt", std::ios::app);

          Count = PositronTrackIDs_gas.size();
          if (KEner < stoppingThreshold)
          {
              addPositronID_gas(uniqueID);
          }
          if (Count < PositronTrackIDs_gas.size())
          {
              G4cout << "Positron stoped in gas count: " << PositronTrackIDs_gas.size() << G4endl;
              X_gas << PPos[0] << ", ";
              Y_gas << PPos[1] << ", ";
              Z_gas << PPos[2] << ", ";
              fEventAction->AddNoP_gas(1);
          }
      } else return;
  } else if (prevolume == fScoringVolume_end) {
      if (particleName == "e+")
      {
          Count = PositronTrackIDs_end.size();
          addPositronID_end(uniqueID);

          if (Count < PositronTrackIDs_end.size())
          {
              fEventAction->AddNoP_end(1);
          }
      } else if (particleName == "e-") {
          Count = ElectronTrackIDs_end.size();
          addElectronID_end(uniqueID);

          if (Count < ElectronTrackIDs_end.size())
          {
              fEventAction->AddNoE_end(1);
          }
      } else return;
  } else return;
}

//G4cout << G4endl << "Particl name: " << particleName << ", TrackID: " << trackID <<  G4endl;

/*G4cout << G4endl << "Size of the positron unsorted set " << PositronTrackIDs.size()
                 << G4endl << "Count of positrons " << positronCount;

          G4cout << G4endl << "All unique IDs:" << std::endl;
          for (const auto& id : PositronTrackIDs) {
              G4cout << id << G4endl;
          }*/

