#include "EventAction.hh"
#include "RunAction.hh"
#include "G4Event.hh"

EventAction::EventAction(RunAction* runAction) : fRunAction(runAction) {}

void EventAction::BeginOfEventAction(const G4Event* event)
{
  G4int eventID = event->GetEventID();
  if (eventID % 10 == 0) {  // Print every 1000 events to avoid flooding output
      G4cout << "Starting Event: " << eventID << G4endl;
  }
  fEdep = 0.;
  fNoP_at = 0;
  fNoE_at = 0;
  fNoP_end = 0;
  fNoE_end = 0;
  fNoP_ad = 0;
  fNoE_ad = 0;
  fNoP_El = 0;
  fNoE_El = 0;
  fNoP_gas = 0;
}

void EventAction::EndOfEventAction(const G4Event*)
{
  // accumulate statistics in run action
  fRunAction->AddEdep(fEdep);
  fRunAction->AddNoP_at(fNoP_at);
  fRunAction->AddNoE_at(fNoE_at);
  fRunAction->AddNoP_end(fNoP_end);
  fRunAction->AddNoE_end(fNoE_end);
  fRunAction->AddNoP_ad(fNoP_ad);
  fRunAction->AddNoE_ad(fNoE_ad);
  fRunAction->AddNoP_El(fNoP_El);
  fRunAction->AddNoE_El(fNoE_El);
  fRunAction->AddNoP_gas(fNoP_gas);
}
