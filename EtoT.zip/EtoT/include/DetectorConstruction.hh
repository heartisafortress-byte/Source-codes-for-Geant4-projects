#include "G4VUserDetectorConstruction.hh"
#include "G4VSensitiveDetector.hh"
#include "G4Threading.hh"
#include "globals.hh"

#include <CLHEP/Units/SystemOfUnits.h>

class G4VPhysicalVolume;
class G4LogicalVolume;
class G4FieldManager;
class G4GenericMessenger;
class EMField;

/// Detector construction class to define materials and geometry.

class DetectorConstruction : public G4VUserDetectorConstruction
{
  public:
    DetectorConstruction();
    ~DetectorConstruction() override;
    void ConstructSDandField() override;

    void SetFieldValue();

    G4VPhysicalVolume* Construct() override;

    G4LogicalVolume* GetScoringVolumeT() const { return fScoringVolumeT; }
    G4LogicalVolume* GetScoringVolume_at() const { return fScoringVolume_at; }
    G4LogicalVolume* GetScoringVolume_end() const { return fScoringVolume_end; }
    G4LogicalVolume* GetScoringVolume_ad() const { return fScoringVolume_ad; }
    G4LogicalVolume* GetScoringVolume_El() const { return fScoringVolume_El; }
    G4LogicalVolume* GetScoringVolume_gas() const { return fScoringVolume_gas; }

private:
    static G4ThreadLocal EMField* fEMField;
    static G4ThreadLocal G4FieldManager* fFieldMgr;
    G4LogicalVolume* fMagneticLogical = nullptr;

  protected:
    G4LogicalVolume* fScoringVolumeT = nullptr;
    G4LogicalVolume* fScoringVolume_at = nullptr;
    G4LogicalVolume* fScoringVolume_end = nullptr;
    G4LogicalVolume* fScoringVolume_ad = nullptr;
    G4LogicalVolume* fScoringVolume_El = nullptr;
    G4LogicalVolume* fScoringVolume_gas = nullptr;
};
