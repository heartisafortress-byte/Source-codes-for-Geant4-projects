#include "EMField.hh"

#include "G4SystemOfUnits.hh"

# include <cmath>
# define M_PI           3.14159265358979323846  /* pi */

EMField::EMField(){}

EMField::~EMField(){}

void EMField::GetFieldValue(const G4double Point[4], double* bField) const
{
    // Constants
    G4double mu0 = 4 * M_PI/10000000; // N/A^2
    G4double B0p = 5; // Tesla
    G4double B0c = 0.5; // Tesla
    G4double R = 0.075; // Meter
    G4double NIp = 2*B0p*R/mu0;
    G4double NIc = 2*B0c*R/mu0;

    G4double x = Point[0]/1000;
    G4double y = Point[1]/1000;
    G4double r = sqrt(pow(Point[0]/1000,2)+pow(Point[1]/1000,2));
    G4double z = Point[2]/1000;
    G4double c = mu0*NIp*pow(R,2.0)/2;
    G4double cc = mu0*NIc*pow(R,2.0)/2;

    // Magnetic field paraxial
    bField[0] = (x/2 * 3*c*(z-1)/pow(pow(R,2)+pow((z-1),2),2.5) + x/2 * 3*c*(z+1)/pow(pow(R,2)+pow((z+1),2),2.5)) * tesla + // first term
                (x*r*r/16*3*c*(15*(z+1)/pow(pow(R,2)+pow((z+1),2),3.5)-35*pow((z+1),3)/pow(pow(R,2)+pow((z+1),2),4.5)) + x*r*r/16*3*c*(15*(z-1)/pow(pow(R,2)+pow((z-1),2),3.5)-35*pow((z-1),3)/pow(pow(R,2)+pow((z-1),2),4.5)))* tesla; // second term
    bField[1] = (y/2 * 3*c*(z-1)/pow(pow(R,2)+pow((z-1),2),2.5) + y/2 * 3*c*(z+1)/pow(pow(R,2)+pow((z+1),2),2.5)) * tesla + // first term
                (y*r*r/16*3*c*(15*(z+1)/pow(pow(R,2)+pow((z+1),2),3.5)-35*pow((z+1),3)/pow(pow(R,2)+pow((z+1),2),4.5)) + y*r*r/16*3*c*(15*(z-1)/pow(pow(R,2)+pow((z-1),2),3.5)-35*pow((z-1),3)/pow(pow(R,2)+pow((z-1),2),4.5)))* tesla; // second term
    bField[2] = (c/pow(pow(R,2)+pow((z-1),2),1.5) + c/pow(pow(R,2)+pow((z+1),2),1.5)) * tesla + // first term
                (r*r/4*3*c*(1/pow(pow(R,2)+pow((z+1),2),2.5) + 5*pow((z+1),2)/pow(pow(R,2)+pow((z+1),2),3.5)) + r*r/4*3*c*(1/pow(pow(R,2)+pow((z-1),2),2.5) + 5*pow((z-1),2)/pow(pow(R,2)+pow((z-1),2),3.5))) * tesla; // second term

    for (int i=0; i<=180/7.5; i++)
    {
        bField[0] = bField[0] + (x/2 * 3*cc*(z +0.9-i*0.075)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),2.5) + x*r*r/16*3*cc*(15*(z +0.9-i*0.075)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),3.5)-35*pow((z +0.9-i*0.075),3)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),4.5))) * tesla;
        bField[1] = bField[1] + (y/2 * 3*cc*(z +0.9-i*0.075)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),2.5) + y*r*r/16*3*cc*(15*(z +0.9-i*0.075)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),3.5)-35*pow((z +0.9-i*0.075),3)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),4.5))) * tesla;;
        bField[2] = bField[2] + (cc/pow(pow(R,2)+pow((z +0.9-i*0.075),2),1.5) + r*r/4*3*cc*(1/pow(pow(R,2)+pow((z +0.9-i*0.075),2),2.5) + 5*pow((z +0.9-i*0.075),2)/pow(pow(R,2)+pow((z +0.9-i*0.075),2),3.5))) * tesla;
    }

    // Electric field
    bField[3] = 0.;
    bField[4] = 0.;
    if (Point[3] > 5*ns)
    {
        bField[5] = 0.;
    } else {
        if (z>-0.75 && z<-0.25)
        {
            bField[5] = -6000*kilovolt/m;
        } else {
            bField[5] = 0.;
        }
    }
}

