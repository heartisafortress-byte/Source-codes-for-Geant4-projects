#include "G4UserSteppingAction.hh"
#include <unordered_set>
#include "globals.hh"

class G4LogicalVolume;
class G4Step;

class EventAction;
class RunAction;

class SteppingAction : public G4UserSteppingAction
{
  public:
    SteppingAction(EventAction* eventAction);
    ~SteppingAction() override = default;

    // method from the base class
    void UserSteppingAction(const G4Step*) override;

  private:
    EventAction* fEventAction = nullptr;
    G4LogicalVolume* fScoringVolumeT = nullptr;
    G4LogicalVolume* fScoringVolume_at = nullptr;
    G4LogicalVolume* fScoringVolume_end = nullptr;
    G4LogicalVolume* fScoringVolume_ad = nullptr;
    G4LogicalVolume* fScoringVolume_El = nullptr;
    G4LogicalVolume* fScoringVolume_gas = nullptr;
};

